# AppGym

App Android 100 % local para registrar entrenamientos: ejercicios, pesos/repeticiones y rutinas por día de la semana. Sin cuentas ni internet; los datos viven en una base de datos Room en el móvil.

## Funciones
- **Hoy**: rutina(s) asignadas al día actual, con progreso de series por ejercicio. Toca un ejercicio para registrar series.
- **Rutinas**: crea rutinas, asígnalas a un día y añade ejercicios con series/reps objetivo.
- **Ejercicios**: catálogo editable (trae algunos de ejemplo). Toca uno para registrar series sueltas.
- **Historial**: todas las series agrupadas por fecha.
- Al registrar un ejercicio ves tu mejor peso y la última sesión, y se precarga el último peso/reps.

## Compilar
- **GitHub Actions**: cada push a `main` genera el APK (Actions → último run → artefacto `app-debug`).
- **Android Studio**: abrir la carpeta y ejecutar `app` con el móvil por USB.

Pila: Kotlin, Jetpack Compose (Material 3), Navigation, Room + KSP. minSdk 26.
