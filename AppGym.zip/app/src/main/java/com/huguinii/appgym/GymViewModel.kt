package com.huguinii.appgym

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.time.LocalDate

class GymViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = GymDatabase.get(app).gymDao()

    val exercises = dao.exercises()
    val routines = dao.routines()
    val history = dao.history()

    fun exercise(id: Long) = dao.exercise(id)
    fun routine(id: Long) = dao.routine(id)
    fun routinesForDay(day: Int) = dao.routinesForDay(day)
    fun routineExercises(routineId: Long) = dao.routineExercises(routineId)
    fun setsForDay(exerciseId: Long, day: Long) = dao.setsForDay(exerciseId, day)
    fun lastSession(exerciseId: Long, day: Long) = dao.lastSession(exerciseId, day)
    fun bestWeight(exerciseId: Long) = dao.bestWeight(exerciseId)

    fun addExercise(name: String, group: String) {
        viewModelScope.launch { dao.insertExercise(Exercise(name = name, muscleGroup = group)) }
    }

    fun deleteExercise(exercise: Exercise) {
        viewModelScope.launch { dao.deleteExercise(exercise) }
    }

    fun addRoutine(name: String, day: Int) {
        viewModelScope.launch { dao.insertRoutine(Routine(name = name, dayOfWeek = day)) }
    }

    fun updateRoutineDay(routine: Routine, day: Int) {
        viewModelScope.launch { dao.updateRoutine(routine.copy(dayOfWeek = day)) }
    }

    fun deleteRoutine(routine: Routine) {
        viewModelScope.launch { dao.deleteRoutine(routine) }
    }

    fun addRoutineExercise(routineId: Long, exerciseId: Long, sets: Int, reps: Int) {
        viewModelScope.launch {
            dao.insertRoutineExercise(
                RoutineExercise(routineId = routineId, exerciseId = exerciseId, targetSets = sets, targetReps = reps)
            )
        }
    }

    fun removeRoutineExercise(item: RoutineExercise) {
        viewModelScope.launch { dao.deleteRoutineExercise(item) }
    }

    fun addSet(exerciseId: Long, weight: Float, reps: Int) {
        viewModelScope.launch {
            dao.insertSet(
                SetLog(exerciseId = exerciseId, epochDay = LocalDate.now().toEpochDay(), weight = weight, reps = reps)
            )
        }
    }

    fun deleteSet(set: SetLog) {
        viewModelScope.launch { dao.deleteSet(set) }
    }
}
