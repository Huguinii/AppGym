package com.huguinii.appgym

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DAY_LABELS = listOf("L", "M", "X", "J", "V", "S", "D")
private val DAY_NAMES = listOf("Sin día", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")

private fun fmtKg(w: Float): String = if (w % 1f == 0f) w.toInt().toString() else w.toString()

private fun fmtDate(epochDay: Long): String =
    LocalDate.ofEpochDay(epochDay)
        .format(DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.forLanguageTag("es-ES")))

@Composable
private fun ScreenTitle(text: String) {
    Text(text, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 12.dp))
}

@Composable
private fun DayPicker(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        FilterChip(selected = selected == 0, onClick = { onSelect(0) }, label = { Text("Ninguno") })
        DAY_LABELS.forEachIndexed { i, label ->
            FilterChip(selected = selected == i + 1, onClick = { onSelect(i + 1) }, label = { Text(label) })
        }
    }
}

// ───────────────────────── HOY ─────────────────────────

@Composable
fun TodayScreen(vm: GymViewModel, onOpenExercise: (Long) -> Unit) {
    val day = LocalDate.now().dayOfWeek.value
    val routines by remember(day) { vm.routinesForDay(day) }.collectAsState(initial = emptyList())

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Hoy · ${DAY_NAMES[day]}")
        if (routines.isEmpty()) {
            Text(
                "No tienes ninguna rutina asignada a hoy. Crea una en la pestaña Rutinas y elige su día, " +
                    "o registra series sueltas desde Ejercicios."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(routines, key = { it.id }) { routine ->
                    TodayRoutineCard(vm, routine, onOpenExercise)
                }
            }
        }
    }
}

@Composable
private fun TodayRoutineCard(vm: GymViewModel, routine: Routine, onOpen: (Long) -> Unit) {
    val entries by remember(routine.id) { vm.routineExercises(routine.id) }.collectAsState(initial = emptyList())
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(routine.name, style = MaterialTheme.typography.titleLarge)
            if (entries.isEmpty()) {
                Text("Esta rutina aún no tiene ejercicios.", style = MaterialTheme.typography.bodySmall)
            }
            entries.forEach { d ->
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(d.exercise.id) }.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(d.exercise.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Objetivo: ${d.link.targetSets} × ${d.link.targetReps}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    SetsDone(vm, d.exercise.id, d.link.targetSets)
                }
            }
        }
    }
}

@Composable
private fun SetsDone(vm: GymViewModel, exerciseId: Long, target: Int) {
    val epochToday = remember { LocalDate.now().toEpochDay() }
    val sets by remember(exerciseId) { vm.setsForDay(exerciseId, epochToday) }.collectAsState(initial = emptyList())
    Text("${sets.size}/$target series", style = MaterialTheme.typography.labelLarge)
}

// ───────────────────────── RUTINAS ─────────────────────────

@Composable
fun RoutinesScreen(vm: GymViewModel, onOpen: (Long) -> Unit) {
    val routines by vm.routines.collectAsState(initial = emptyList())
    var showDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Rutinas")
        Button(onClick = { showDialog = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Nueva rutina")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(routines, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(r.id) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(r.name, style = MaterialTheme.typography.titleMedium)
                        Text(DAY_NAMES[r.dayOfWeek], style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (showDialog) {
        var name by remember { mutableStateOf("") }
        var day by remember { mutableStateOf(0) }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Nueva rutina") },
            text = {
                Column {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nombre (ej. Pecho y tríceps)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    DayPicker(day) { day = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        vm.addRoutine(name.trim(), day)
                        showDialog = false
                    }
                }) { Text("Crear") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun RoutineDetailScreen(vm: GymViewModel, routineId: Long, onBack: () -> Unit) {
    val routine by remember(routineId) { vm.routine(routineId) }.collectAsState(initial = null)
    val entries by remember(routineId) { vm.routineExercises(routineId) }.collectAsState(initial = emptyList())
    var showAdd by remember { mutableStateOf(false) }
    val r = routine

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← Volver") }
        if (r == null) {
            Text("Rutina no encontrada.")
        } else {
            ScreenTitle(r.name)
            Text("Día de la semana", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            DayPicker(r.dayOfWeek) { vm.updateRoutineDay(r, it) }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Añadir ejercicio")
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(entries, key = { it.link.id }) { d ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(d.exercise.name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${d.link.targetSets} series × ${d.link.targetReps} reps",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            IconButton(onClick = { vm.removeRoutineExercise(d.link) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Quitar")
                            }
                        }
                    }
                }
            }
            TextButton(onClick = {
                vm.deleteRoutine(r)
                onBack()
            }) { Text("Eliminar rutina", color = MaterialTheme.colorScheme.error) }
        }
    }

    if (showAdd) {
        AddRoutineExerciseDialog(vm, routineId) { showAdd = false }
    }
}

@Composable
private fun AddRoutineExerciseDialog(vm: GymViewModel, routineId: Long, onDismiss: () -> Unit) {
    val exercises by vm.exercises.collectAsState(initial = emptyList())
    var selected by remember { mutableStateOf<Long?>(null) }
    var sets by remember { mutableStateOf("3") }
    var reps by remember { mutableStateOf("10") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir ejercicio") },
        text = {
            Column {
                if (exercises.isEmpty()) Text("Primero crea ejercicios en la pestaña Ejercicios.")
                LazyColumn(Modifier.heightIn(max = 220.dp)) {
                    items(exercises, key = { it.id }) { e ->
                        Row(
                            Modifier.fillMaxWidth().clickable { selected = e.id },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selected == e.id, onClick = { selected = e.id })
                            Text(e.name)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row {
                    OutlinedTextField(
                        value = sets,
                        onValueChange = { sets = it },
                        label = { Text("Series") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = reps,
                        onValueChange = { reps = it },
                        label = { Text("Reps") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val id = selected
                if (id != null) {
                    vm.addRoutineExercise(routineId, id, sets.toIntOrNull() ?: 3, reps.toIntOrNull() ?: 10)
                    onDismiss()
                }
            }) { Text("Añadir") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

// ───────────────────────── EJERCICIOS ─────────────────────────

@Composable
fun ExercisesScreen(vm: GymViewModel, onOpen: (Long) -> Unit) {
    val exercises by vm.exercises.collectAsState(initial = emptyList())
    var showAdd by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Exercise?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Ejercicios")
        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Nuevo ejercicio")
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(exercises, key = { it.id }) { e ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(e.id) }) {
                    Row(
                        Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name, style = MaterialTheme.typography.titleMedium)
                            if (e.muscleGroup.isNotBlank()) {
                                Text(e.muscleGroup, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        IconButton(onClick = { toDelete = e }) {
                            Icon(Icons.Default.Delete, contentDescription = "Eliminar")
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var group by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Nuevo ejercicio") },
            text = {
                Column {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nombre") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = group,
                        onValueChange = { group = it },
                        label = { Text("Grupo muscular (opcional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        vm.addExercise(name.trim(), group.trim())
                        showAdd = false
                    }
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancelar") } }
        )
    }

    val pending = toDelete
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Eliminar ${pending.name}?") },
            text = { Text("Se borrarán también todas sus series registradas y se quitará de las rutinas.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteExercise(pending)
                    toDelete = null
                }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }
}

// ───────────────────────── REGISTRO DE SERIES ─────────────────────────

@Composable
fun LogScreen(vm: GymViewModel, exerciseId: Long, onBack: () -> Unit) {
    val epochToday = remember { LocalDate.now().toEpochDay() }
    val exercise by remember(exerciseId) { vm.exercise(exerciseId) }.collectAsState(initial = null)
    val todaySets by remember(exerciseId) { vm.setsForDay(exerciseId, epochToday) }.collectAsState(initial = emptyList())
    val last by remember(exerciseId) { vm.lastSession(exerciseId, epochToday) }.collectAsState(initial = emptyList())
    val best by remember(exerciseId) { vm.bestWeight(exerciseId) }.collectAsState(initial = null)

    var weight by remember(last) { mutableStateOf(last.firstOrNull()?.let { fmtKg(it.weight) } ?: "") }
    var reps by remember(last) { mutableStateOf(last.firstOrNull()?.reps?.toString() ?: "") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← Volver") }
        ScreenTitle(exercise?.name ?: "")

        val bestWeight = best
        if (bestWeight != null) {
            Text("Mejor peso: ${fmtKg(bestWeight)} kg", style = MaterialTheme.typography.titleSmall)
        }
        if (last.isNotEmpty()) {
            Text(
                "Última vez (${fmtDate(last.first().epochDay)}): " +
                    last.joinToString(" · ") { "${fmtKg(it.weight)}×${it.reps}" },
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(12.dp))

        Row {
            OutlinedTextField(
                value = weight,
                onValueChange = { weight = it },
                label = { Text("Peso (kg)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(
                value = reps,
                onValueChange = { reps = it },
                label = { Text("Repeticiones") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                val w = weight.replace(',', '.').toFloatOrNull()
                val r = reps.toIntOrNull()
                if (w != null && r != null && r > 0) {
                    vm.addSet(exerciseId, w, r)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Guardar serie") }

        Spacer(Modifier.height(16.dp))
        Text("Hoy", style = MaterialTheme.typography.titleMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(todaySets.withIndex().toList(), key = { it.value.id }) { (index, s) ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Serie ${index + 1}: ${fmtKg(s.weight)} kg × ${s.reps}")
                    IconButton(onClick = { vm.deleteSet(s) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Borrar serie")
                    }
                }
            }
        }
    }
}

// ───────────────────────── HISTORIAL ─────────────────────────

@Composable
fun HistoryScreen(vm: GymViewModel) {
    val history by vm.history.collectAsState(initial = emptyList())
    val grouped = remember(history) { history.groupBy { it.log.epochDay } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle("Historial")
        if (history.isEmpty()) {
            Text("Todavía no has registrado ninguna serie.")
        } else {
            LazyColumn {
                grouped.forEach { (day, logs) ->
                    item(key = "d$day") {
                        Text(
                            fmtDate(day),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                        )
                    }
                    items(logs, key = { "l${it.log.id}" }) { l ->
                        Text("${l.exerciseName} — ${fmtKg(l.log.weight)} kg × ${l.log.reps}")
                    }
                }
            }
        }
    }
}
