package com.huguinii.appgym

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Relation
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val muscleGroup: String = ""
)

/** dayOfWeek: 0 = sin día, 1 = lunes ... 7 = domingo */
@Entity(tableName = "routines")
data class Routine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dayOfWeek: Int = 0
)

@Entity(
    tableName = "routine_exercises",
    foreignKeys = [
        ForeignKey(entity = Routine::class, parentColumns = ["id"], childColumns = ["routineId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Exercise::class, parentColumns = ["id"], childColumns = ["exerciseId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("routineId"), Index("exerciseId")]
)
data class RoutineExercise(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val routineId: Long,
    val exerciseId: Long,
    val targetSets: Int,
    val targetReps: Int
)

/** epochDay = LocalDate.toEpochDay() */
@Entity(
    tableName = "set_logs",
    foreignKeys = [
        ForeignKey(entity = Exercise::class, parentColumns = ["id"], childColumns = ["exerciseId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("exerciseId"), Index("epochDay")]
)
data class SetLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val exerciseId: Long,
    val epochDay: Long,
    val weight: Float,
    val reps: Int
)

data class RoutineExerciseDetail(
    @Embedded val link: RoutineExercise,
    @Relation(parentColumn = "exerciseId", entityColumn = "id") val exercise: Exercise
)

data class SetLogWithName(
    @Embedded val log: SetLog,
    val exerciseName: String
)

@Dao
interface GymDao {
    // Ejercicios
    @Query("SELECT * FROM exercises ORDER BY name COLLATE NOCASE")
    fun exercises(): Flow<List<Exercise>>

    @Query("SELECT * FROM exercises WHERE id = :id")
    fun exercise(id: Long): Flow<Exercise?>

    @Insert
    suspend fun insertExercise(exercise: Exercise): Long

    @Delete
    suspend fun deleteExercise(exercise: Exercise)

    // Rutinas
    @Query("SELECT * FROM routines ORDER BY dayOfWeek, name COLLATE NOCASE")
    fun routines(): Flow<List<Routine>>

    @Query("SELECT * FROM routines WHERE id = :id")
    fun routine(id: Long): Flow<Routine?>

    @Query("SELECT * FROM routines WHERE dayOfWeek = :day ORDER BY name COLLATE NOCASE")
    fun routinesForDay(day: Int): Flow<List<Routine>>

    @Insert
    suspend fun insertRoutine(routine: Routine): Long

    @Update
    suspend fun updateRoutine(routine: Routine)

    @Delete
    suspend fun deleteRoutine(routine: Routine)

    // Ejercicios de una rutina
    @Transaction
    @Query("SELECT * FROM routine_exercises WHERE routineId = :routineId ORDER BY id")
    fun routineExercises(routineId: Long): Flow<List<RoutineExerciseDetail>>

    @Insert
    suspend fun insertRoutineExercise(item: RoutineExercise)

    @Delete
    suspend fun deleteRoutineExercise(item: RoutineExercise)

    // Series
    @Insert
    suspend fun insertSet(set: SetLog)

    @Delete
    suspend fun deleteSet(set: SetLog)

    @Query("SELECT * FROM set_logs WHERE exerciseId = :exerciseId AND epochDay = :day ORDER BY id")
    fun setsForDay(exerciseId: Long, day: Long): Flow<List<SetLog>>

    @Query(
        "SELECT * FROM set_logs WHERE exerciseId = :exerciseId AND epochDay = " +
            "(SELECT MAX(epochDay) FROM set_logs WHERE exerciseId = :exerciseId AND epochDay < :day) ORDER BY id"
    )
    fun lastSession(exerciseId: Long, day: Long): Flow<List<SetLog>>

    @Query("SELECT MAX(weight) FROM set_logs WHERE exerciseId = :exerciseId")
    fun bestWeight(exerciseId: Long): Flow<Float?>

    @Query(
        "SELECT set_logs.*, exercises.name AS exerciseName FROM set_logs " +
            "JOIN exercises ON exercises.id = set_logs.exerciseId " +
            "ORDER BY set_logs.epochDay DESC, set_logs.id DESC"
    )
    fun history(): Flow<List<SetLogWithName>>
}

@Database(
    entities = [Exercise::class, Routine::class, RoutineExercise::class, SetLog::class],
    version = 2,
    exportSchema = false
)
abstract class GymDatabase : RoomDatabase() {
    abstract fun gymDao(): GymDao

    companion object {
        @Volatile
        private var instance: GymDatabase? = null

        private val seed = listOf(
            "Press banca" to "Pecho",
            "Press inclinado" to "Pecho",
            "Sentadilla" to "Pierna",
            "Prensa" to "Pierna",
            "Peso muerto" to "Espalda",
            "Remo con barra" to "Espalda",
            "Dominadas" to "Espalda",
            "Press militar" to "Hombro",
            "Curl de bíceps" to "Brazo",
            "Extensión de tríceps" to "Brazo"
        )

        private val seedCallback = object : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                seed.forEach { (name, group) ->
                    db.execSQL(
                        "INSERT INTO exercises (name, muscleGroup) VALUES (?, ?)",
                        arrayOf<Any>(name, group)
                    )
                }
            }
        }

        fun get(context: Context): GymDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    GymDatabase::class.java,
                    "gym_database"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(seedCallback)
                    .build()
                    .also { instance = it }
            }
    }
}
